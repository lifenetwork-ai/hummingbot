# Checkpoint and background-poll optimization

Scope: reuse the recorder, owner fencing and existing PostgreSQL schema. Preserve
terminal-fill proof, Decimal precision, HALT and recovery behavior. No authority
cache, new service or Redis dependency.

## P1 — Position checkpoint batch

- [x] Red: require one lookup/transaction for multiple position snapshots; test
  exact values, repeated keys, rollback, stale ownership and retained in-memory
  exposure after failure.
- [x] Batch recorder writes and submit the complete orchestrator snapshot once.
  Keep connector reads and ownership-connection access on the engine loop.
- [x] Green: native recorder/executor/terminal-proof and real PostgreSQL tests.
- [x] Record evidence and commit. Batching does not claim to remove all synchronous
  recorder IO or explain historical probe latency.

## P2 — Idle reconciliation polling

- [x] Red: an empty queue must not lock bot_state; verify completed/stale candidates,
  owner changes and concurrent claims cannot weaken the existing transaction.
- [x] Add a non-locking candidate probe; recheck under the existing owner/control
  lock before claiming work, keeping the current lock order.
- [x] Green: PostgreSQL concurrency/ownership tests and API/service regressions.
- [x] Record evidence and commit.

## P3 — Funding discovery measurement

- [x] Measure the existing history aggregate with EXPLAIN ANALYZE on a disposable
  large PostgreSQL dataset; preserve raw evidence under build/.
- [x] Change the query only if measured cost warrants it; preserve historical
  pair discovery and earliest timestamps, including newly imported old orders.
- [x] Run relevant regressions, document limitations and commit results.

## Completion

- [x] Run the combined relevant native/PostgreSQL checks, update progress and
  publish an optimization report. New source does not inherit prior image/load/
  Demo acceptance; do not trade, repair Demo data or reset HALT for this task.

Completed source checks: 2,357 native tests plus 11 subtests, 307 PostgreSQL
tests and Swagger pass. [Report/evidence](../../reports/performance/mm-checkpoint-poll-optimization.md).
Those source checks do not claim new image/load/Demo acceptance.

## Follow-up image/load/Demo rerun — requested 2026-11-03

- [x] Before full load, reproduce inherited OKX spot direction reversal retaining
  an obsolete opposite aggregate (three real-PG Reds). Treat spot direction as
  mutable identity, preserving the existing row ID; keep perpetual hedge keys.
  Refuse ambiguous historical/input spot aggregates without deleting/repairing
  exposure. Verify exact reverse/zero/replay/restart and existing batch fences.
- [x] Validate and commit the corrective source (native2,357 +11 subtests, PG312);
  rebuild in the image item below. The superseded6d9f9f01
  image's three passing E2E groups do not qualify the corrected source. The paused
  pipeline intentionally stops at source-freeze before starting R1.
- [x] Red/Green: reject existing ambiguous OKX spot position rows when loading
  startup holds, before valuation or quoting; preserve all rows and allow scoped
  reads for unrelated controllers. Targeted real-PostgreSQL tests pass; full
  native regression and Swagger pass. Requalify the image after this safety fix.
- [x] Build and hash-verify a current-source amd64 image; run packaged smoke and
  focused MM checkpoint/stop/restart scenarios before full load.
- [x] Run unchanged full R1 (warmup/mixed/burst/60-minute soak/six fault groups),
  independently verify accounting, memory, process and continuity evidence.
- [x] Run and independently verify matched ordinary-entrypoint R2.
- [x] Read-only Demo preflight and inspect the missing-volume recovery gap.
  An older backup is not current ledger proof; do not repair history or clear HALT
  without explicit operator review of a concrete proposal.
- [x] Obtain operator approval for the documented reconstruction after its isolated
  dry run: preserve1,257 orders/six original fills, backfill23 terminal orders/five
  actual fills, recompute three aggregates; disclose unavailable executor/session
  events. No HALT reset or history deletion. Execute only after verified load.
- [x] Verify Demo profiles, modes, Random, Stop/restart and aggregate order
  quantity/fees/positions where history permits; report incomplete scope honestly.
- [x] Finish individual REST trade-ID verification for seven new natural fills;
  a later read matches all IDs, quantities, prices, maker sides and original fees.
- [x] Publish evidence, close verified checklist items, clean owned resources and
  commit. Preserve prior failed results and unrelated Docker resources.

Previous artifact 5b2aaaa7, source 8252d797e: packaged hashes, smoke, three
focused E2E groups and the warmup/mixed/burst windows passed. Its soak was
deliberately stopped at approximately 32 minutes after a startup ambiguity was
reproduced; it is not a completed R1. Demo is gated on acceptance of the fixed
image. The corrected image e9845e3f, source d68d74e07, passes full local R1/R2;
see the [load report](../../reports/release/mm-checkpoint-poll-load.md).
[Approved recovery proposal](../../reports/demo/checkpoint-poll-recovery-proposal.md).

Later recovery and fix status: [checkpoint recovery report](../../reports/demo/okx-checkpoint-recovery.md).
Final `51d4d879` full R1/R2 and REST fill proof:
[release report](../../reports/release/mm-checkpoint-final-release.md).
