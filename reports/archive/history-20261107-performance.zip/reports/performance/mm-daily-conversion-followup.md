# Daily fee aggregation and remaining availability investigation

2026-11-04 (Asia/Saigon). **Latest candidatef4d90bc7:** three packaged E2E
groups and four controlled reporting faults pass. The unchanged standalone hour
passes with79,200 HTTP200 responses, no stale/error, primary/auxiliary p99
615.65/565.42ms and3,594 matched synthetic fills/fees/positions. The prior
300s probe remains failed at1,094.27/1,112.11ms p99. A separate traced probe
passes at823.21/734.17ms and confirms worker queueing during slow bursts;
the original exclusive trigger remains unproven. Neither this hour nor
diagnostics transfer full R1/R2 acceptance.
See the [retry follow-up](#bounded-timeout-retry-follow-up--2026-11-04).

**Preceding candidate50f96001:** source, three packaged E2E groups, two controlled
reporting faults and positive Demo fills/restart pass. The rich 600s probe fails
reporting/latency; its hour soak fails only the zero-degraded-response gate.
Earlier failed results remain in the
[controller/persistence report](../release/mm-controller-persistence-release.md).
[Evidence](mm-daily-conversion-followup-evidence.json),
[checklist](../../docs/plans/OKX_DEMO_CURRENT_IMAGE_ACCEPTANCE.md#reportingprobeguard-follow-up--requested-2026-11-04).

## Confirmed redundant work and source change

The original fill aggregate inlines its conversion predicate into three aggregate
filters. A real PostgreSQL Red regression performs 600 original-fee array parses
for 200 zero-conversion fills. The candidate computes nonzero-converted and
zero-fee-converted counts once in the existing daily aggregate, then derives the
three result fields from those small daily totals. The Green query executes 200
parses. There is no additional full-history materialization or aggregate pass.

The USDT sum excludes other quote assets. Invalid zero conversions cannot alter
its numeric total; an explicit validity count retains NULL when no conversion is
valid. Regression coverage includes mixed valid/missing/zero/foreign conversions,
rebates, exact original-currency amounts, late fills, date boundaries and a single
repeatable-read database snapshot. Response fields and trading authority stay
unchanged. No cache, index, migration, dependency or runtime timeout is added.

## Paired disposable-database measurement

PostgreSQL 14 is limited to 2 CPU / 512 MiB. Five randomized-order paired samples
after warmup are retained for the first three cases; the last uses three. Every
returned value is exactly equal between the original and candidate SQL. These
are diagnostics on one host, not production latency promises.

| Fills / fees | Main fill query before → after, median ms | Complete daily read before → after, median ms |
| --- | ---: | ---: |
| 100k / repeated, nonzero conversion | 323.85 → 301.26 | 775.82 → 773.78 |
| 100k / diverse, zero conversion | 2,250.71 → 1,026.90 | 3,041.33 → 1,899.29 |
| 1M / repeated, nonzero conversion | 2,764.67 → 2,733.73 | 8,448.79 → 7,642.99 |
| 1M / diverse, zero conversion | 26,371.55 → 12,246.17 | 36,764.15 → 23,625.69 |

Diagnostic query deadlines are 90s; bulk fixture setup alone allows 300s after
initial setup-only deadline failures. Shipping statements retain their 2s limit
and 3s I/O deadline. The million-row cases remain beyond that runtime budget.
Two exploratory shapes were not retained: adding classification groups and a
per-row projection boundary did not establish a safe normal-workload benefit.

The old soak timeout used **nonzero** fee conversions, so eliminating repeated
zero-conversion decoding does not establish that historical timeout's root cause.
Plans also show temporary-file sorting in some cases. No global memory/timeout
setting or guard threshold is changed to make the gate pass.

## Independent reference freshness observation

A separate read-only connection subscribes to the same Demo `books` channel for
BTC/ETH/AVAX for 180s, without account access or mutations. It receives 88 AVAX,
401 ETH and 563 BTC messages. AVAX has a 10.96s maximum receive gap and six of
359 point samples exceed the current freshness policy; maximum measured server
book age at spot UID precision is 11.71s. ETH has no stale samples and its maximum
receive gap is 1.55s; BTC also has no stale samples. The public clock response
bounds server-minus-client offset between -0.007s and +0.228s.

This reproduces a real input condition for `stale_reference:okx:AVAX-USDT` even
outside the service. It does not prove the cause of every historical wait, a
continuous outage duration, or the source of `inconsistent_own_depth`. A bounded
private/public observation witness is prepared for the next approved Demo trial;
qualification thresholds and all order guards remain intact.

## Verified image and packaged regression

Image `50f96001` is built from source `14feb47dd`; fixture commit `2e39ad151`
changes tests only. Seven runtime file hashes match and all197 Python package
versions match the preceding image. Runtime
ABI/JIT/TLS/SDK/logging smoke passes. The first packaged matrix proceeds through
nine cases but later times out waiting for quote recovery after the
terminal-before-create fault. Its simulator logs contain transport timeouts; the
original failure lacks a captured database snapshot, so its exclusive cause is
not established. A separate unmodified recovery run passes. That repeat's fault
is armed for7.6s including startup, while the recorded time from first admission
to durable proof is1.57s; those measurements must not be conflated.

Two test-harness weaknesses are independently reproduced with Red tests:
unbounded physical cancellation admission can add replacement batches while ACKs
are held, and a global `creation_pending=0` condition includes unrelated new
intents. The final fixture admits a bounded eight-order batch from a stopped
runtime, verifies matching client/exchange/market identities and durable cancel
rows only for that batch, then releases ACKs. It checks both markets and an
unchanged5s transport envelope. Native65 targeted checks (eleven new) and seven
new real-PG cases pass. A preliminary bounded recovery E2E passes with four spot
and four perpetual cancellations: proof completes in1.28s and release is observed
by2.10s, followed by normal quote recovery, Random/expiry and the intentional DB
outage/recovery case. Existing unbounded lost-ACK faults and all application
trading/HALT/deadline behavior are unchanged. The complete final-fixture matrix
now passes, together with the separate recovery and volatility-defense groups.
No production defect is inferred solely from the first failure.

Native regression passes 2,442 tests plus eleven subtests. The first full
PostgreSQL attempt is stopped after the unchanged original-currency fee query
hits its 2s deadline in the 100k measurement test; 49 other tests passed. Image
C++ compilation overlapped that attempt. This is not a demonstrated quantity or
fee mismatch, and overlap alone does not establish causation. The complete suite
subsequently passes 345 tests without concurrent compilation; the failed log
is retained and a unique historical timeout cause is not established.

## Rich 600-second probe: failed reporting/latency gate

`build/mm-load/20261104-072930-5e4e22` uses the verified shipping image with
MM activity, bounded incident capture, operations reads and the original
thresholds. All12,000 primary and3,000 auxiliary responses are HTTP200. One real
main-fill aggregate reaches its2s SQL deadline, producing13 explicitly degraded
daily responses. Primary p95/p99 are657.20/1,138.16ms; auxiliary p95/p99
661.81/1,072.21ms. The zero-degraded-response and four latency gates fail.
All600 synthetic fills, original fees and positions reconcile exactly. The
active reconciliation command reports incomplete when local state changes
during its read; it does not report invented position differences.

Within the measured window,36 engine and3 API probe episodes recover without
child replacement. Largest logged observation intervals are2.519/1.229s;
the independent incident-clock interval for the largest selected episode is
2.533s. These are different observation points, not quote downtime. In ten
selected retained contexts, maximum tick/controller start gaps reach2.208/1.967s.
Some contexts retain11–12 live orders; others contain empty discrete venue
samples while replacement submissions are observed. Twelve connector submission
returns overlap the largest episode, but a return is not terminal venue proof.
Neither uninterrupted quoting nor zero MM delay is established.

No timing or guard threshold is relaxed. Metadata-only planner statistics are
captured outside measured windows on the disposable database. The seeded
timestamp has one distinct value; the default sort budget is4MiB. Repeated-fee
plans show disk sorting, but these observations alone do not identify the unique
historical timeout/p99 cause. Global JIT/parallel defaults in those statistics
must not be mistaken for the daily query's transaction-local overrides.

## Controlled slow-report isolation: both cases pass

Two separate120s tests inject one server-side2s timeout into the API report:
first a wait, then a CPU-heavy expansion. Both use the shipping image without
runtime-source overlays. Each independently observes two exchange fills during
the actual timeout and a committed-fill witness before it ends. Each reconciles
120 unique fills/fees/positions, retains the same engine PID/owner/session,
produces no HALT, returns to fresh daily data and stops cleanly.

Expected stale replies in these fault tests do not turn the failed healthy probe
into a pass. They demonstrate progress in these two controlled conditions,
not universal isolation from shared CPU, storage or PostgreSQL contention.
An initial runner stops before fixture construction because system Python lacks
pandas; the retained reruns use the established `hummingbot` conda environment.

## Connected Demo: positive spot/perpetual fills and restart pass

Fresh read-only image preflight verifies REST/public/privateWS, modes,
instruments, balances, positions and no pending orders. Stopped upgrade/restart
preserves four ledger hashes. The explicitly approved temporary40USDT-per-market
preset changes only sizing/spread fields; post-only, fee floor and every risk
guard stay intact. Spot follows AVAX briefly, then sideways; after the spot fill,
both markets run. These are connected OKX Demo executions, distinct from the
synthetic load fills above.

| Market | Natural maker execution | Exact original fee paid |
| --- | --- | --- |
| BTC-USDT spot | SELL0.00025896BTC at77,231.2USDT | 0.0159998332416USDT |
| BTC-USDT perpetual | BUY0.0001BTC at77,179.7USDT | 0.001543594USDT |

Individual REST trade IDs match quantity, price and fee; repeated readbacks
retain each row once. Filled-active restart preserves the pinned session,
anchors, deadline and generation. The21 prior fills remain unchanged; final23
rows are unique. Independent terminal review confirms all37 new orders:
35canceled,2filled. Spot cash delta and perpetual base exposure agree with OKX.
The original200/400 catalogue and same canonical container are restored,
trading stopped, no pending orders/mutations or HALT; no DB repair/reset occurs.

The armed bounded read-only guard witness emits no trigger records in this
trial. Historical `inconsistent_own_depth` is not reproduced or causally closed.
Fourteen warnings classify as guard recovery/reduced sizing and two server-time
refresh warnings; no unclassified ERROR remains. The separate180s public-book
observation above still establishes an AVAX freshness input condition, not a new
guard implementation defect. Original private YAML/env hashes remain unchanged.

## Standalone hour: trading/retention checks pass, reporting gate fails

`build/mm-load/20261104-080016-a1e88c` completes one continuous3,600s window
with the original2CPU/2GiB bot,2CPU/512MiB PostgreSQL, pool5, TTL15 and100k
history fixture. All72,000 primary and7,200 auxiliary replies are HTTP200.
Primary p95/p99 are485.92/991.42ms; auxiliary472.47/947.61ms. Latency budgets
pass with little p99 headroom; this is not evidence of a general speedup over
the older image on a changing host.

The only failed budget is `errors`: two statements reach the unchanged2s SQL
deadline, both in the **original-currency fee aggregate**, distinct from the
main aggregate that times out in the short probe. Each produces14 explicitly
stale daily replies,28 total, across4.654s and4.711s response spans. The simulated
venue executes4 and5 fills during those spans; their identities/fees/positions
match later. This does not prove their commits occurred inside those spans or
that quotes were continuously present.

All3,594 synthetic fills, original fees and positions reconcile exactly.
Retention growth is25.6875MiB against64MiB; peak raw cgroup memory is702.48MiB
against1.5GiB. The57 runtime samples have a maximum65.72s wall gap and pass
continuity, HALT, backlog/pool, per-role RSS, FD and thread checks. Supervisor,
engine and API PIDs remain1/32/33; early/late median RSS growth is0/15.625/10.238MiB.
This hour establishes bounded retention for this workload, not absence of every
possible long-lived leak. The runner's printed `RSS` sample is raw cgroup memory;
per-role RSS and cache-adjusted retention are separate measurements.

There are158 recovered engine and13 recovered API probe episodes, with maximum
logged observation intervals4.514/1.534s and no child replacement/service exit
during the window. Minute samples all remain running. The hour has no MM activity
stream, so it cannot prove uninterrupted quoting. Random executes six steps but
draws only follow_token/sideways; full three-scenario coverage is supplied by the
separate E2E matrix, not inferred from this random draw.

Afterward, the original Demo database/canonical service is restarted. A separate
network-isolated restore of the pre-soak backup matches current orders/fills/
positions/executors hashes. Packaged REST/WS/account preflight passes; service
is owner-available, trading-stopped, no HALT/pending mutations/unresolved orders,
on the verified image. Private configuration and seven runtime hashes remain
unchanged. Owned temporary test containers and the sleep inhibitor are removed.

## Remaining acceptance and causal limits

A clean current-image zero-degraded-response gate is **not obtained**. Source
optimization is confirmed for redundant zero-conversion decoding, not a cure
for both reporting statements under contention. Million-row reads remain beyond
the runtime deadline. Further SQL work needs statement-specific plans/profiling
on an isolated representative dataset; increasing deadlines or adding cache
without measurement would conceal the retained acceptance failure.

The unique historical p99/probe cause and historical own-depth cause remain
unproven. Collect the bounded public/private witness on recurrence; do not infer
a guard defect from an old warning or repeat hour gates to recover missing logs.
This standalone soak does not replace full R1 warm/mixed/burst/soak/six-fault and
matched ordinary-entrypoint R2 acceptance, which are not repeated on this image.
The current follow-up is complete with an incomplete release qualification;
there is no new Cloud Run/production acceptance or live-account trading.

Raw diagnostics/helpers: `build/reporting-followup-20261104/`. Discarded or
interrupted experiments are preserved there and are not passing gates.

## Bounded timeout-retry follow-up — 2026-11-04

The requested follow-up keeps SQL and all runtime deadlines unchanged. Exploratory
payload grouping/casts/projections, local sort-memory increases, scalar paths,
signed-sum arithmetic and stored-array prototypes do not establish a safe general
benefit across repeated/diverse fees. No experimental query/schema/cache is kept.
These discarded measurements are not a shipping improvement or passing gate.

The API retries one complete daily read only after an acknowledged PostgreSQL
statement-timeout57014 on an intact session. The failed transaction has rolled
back and released its connection before normal report admission runs again;
queued controls retain priority. Operator cancellation, other/unknown errors,
discarded sessions and shutdown do not trigger this retry. Same-key waiters still
share one flight, including during retry and after a client disconnect. A second
failure retains the original stale/unavailable behavior, observation time,60s
age bound and5s cooldown. It never relabels an old observation as fresh.

A recovered request may take longer: the unchanged2s SQL/3s I/O limits apply to
each attempt, not a new whole-request wall deadline. Both attempts use the same
bounded two-worker executor; no control/trading write is retried. WARNING logs
expose the first timeout and INFO follows only a validated recovered observation.
This repairs transient refresh availability, not the underlying SQL execution
cost or its unique historical cause. English server diagnostics are recognized
narrowly; unknown/localized diagnostics retain the existing fallback.

Native Red4 plus six non-retry controls precedes implementation; final related72
checks pass. Valid real-PG Red2/Green2 uses actual2s server cancellation: a late
fill appears consistently in both counts and original fees after the new snapshot,
while two failures retain stale timestamps/cooldown. Initial incorrect from/to
fixture aliases are corrected and their logs excluded from Red proof. Broad
native2,464 +11 subtests and PostgreSQL354 pass. Imagef4d90bc7 matches nine
runtime file hashes from source d2cdf2a36 and all197 preceding Python package
versions. Three packaged E2E groups pass. Stopped Demo upgrade/restart retains
four ledger hashes, positions and the original configuration; there is no new
connected trading session on this image.

All four120s wait/CPU tests pass on the unmodified image. One injected timeout
recovers a fresh report without stale replies; two exhaust the retry and produce
18 expected stale replies per persistent case, keeping the original observation
time and bounded age. Each case independently witnesses a committed fill during
the first actual timeout, matches120 fills/fees/positions, preserves engine PID/
owner/session, produces no HALT, later returns fresh data and stops cleanly.
Independent log review extends through the last injected timeout plus8s and
finds no ERROR/CRITICAL. These are intentionally impaired tests, not healthy gates.

The300s untraced probe returns all6,600 HTTP200 responses without stale/error
and matches300 fills, but fails primary/auxiliary p99 at1,094.27/1,112.11ms
against1,000ms. Primary/auxiliary p95 are469.65/442.97ms. No daily retry or
server SQL timeout occurs; the retry path cannot explain that run's slow reads.
Cumulative API worker-queue p99 is500.25ms versus0.070ms pool admission and
52.57ms SQL; these are separate distributions including pre-window work, not
additive stages of the same request. The untraced result lacks per-request
correlation. It is retained as failed, even though the later hour passes.

The unchanged standalone3,600s hour on the same image returns72,000 primary
and7,200 auxiliary HTTP200 responses with zero stale/error. Primary p95/p99
are90.32/615.65ms; auxiliary86.38/565.42ms. All3,594 synthetic fills, fees and
positions match. Retained growth is27.68MiB against64MiB and raw cgroup peak
700.95MiB against1.5GiB;58 minute samples have maximum65.90s spacing and retain
supervisor/engine/API PIDs1/37/38. Random visits all three scenarios. No natural
server statement timeout or retry occurs in this hour; four controlled faults
above establish retry behavior, and a changing host prevents attributing the
latency difference exclusively to the API patch.

Within the hour,46 engine probe failures and47 recoveries are logged, plus four
API failure/recovery pairs. A recovery can correspond to a failure preceding the
timed boundary; these counts are not complete in-window episode counts. Maximum
logged recovered observation intervals are3.098/1.151s, without child replacement.
There is no MM activity stream in this hour, so neither probe recovery nor the
matching ledger proves uninterrupted quoting.

After the hour, a network-isolated restore of the private pre-soak backup matches
orders/fills/positions/executors hashes. Packaged read-only REST/public/privateWS
preflight passes; canonical Demo returns owner-available, trading-stopped, no
HALT/pending mutation/unresolved order. Original private configuration is intact.
The current healthy-hour reporting gate passes; earlier50f96001 failures remain
failed. Full release qualification remains incomplete because of the retained
short p99 failure and the absence of a new full R1/R2 run.

## Request-level latency investigation — 2026-11-04

One isolated300s traced diagnostic follows the unchanged hour and verified Demo
restoration. It uses the samef4d90bc7 image,100k history, two application CPUs,
two database CPUs,2GiB/512MiB limits, pool/worker/cache policy and20 primary plus
two auxiliary reads/s. The extra bounded trace sampler is declared diagnostic
overhead, not a controlled-away variable or release acceptance.

All6,600 replies are HTTP200 with no stale/error;300 synthetic fills, original
fees and positions match. Primary p95/p99 are140.14/823.21ms; auxiliary96.90/
734.17ms. The retained trace has34 clients above1s:32 primary and two auxiliary,
all34 matched to their API-process handler roots. Passing p99 can coexist with
these individual outliers because they comprise less than1% of each population.
This result does not reclassify the earlier untraced short failure.

### Observed delay mechanism

The same two physical API workers serve reports, history and ordinary reads.
Slow SQL/round trips and delayed completion create queueing behind those jobs;
queued controls retain dispatch priority, but cannot preempt an active DB call.
The following request IDs are from the same traced diagnostic:

| Request suffix / route | Client total ms | Worker wait ms | Largest SQL span ms |
| --- | ---: | ---: | ---: |
|1272 / balances|1,335.61|1,066.19|12.03|
|1273 / positions|1,282.55|1,091.81|4.82|
|1274 / session events|1,307.67|1,124.33|5.05|
|4966 / daily|1,686.52|10.64|758.18|

These are individually matched timings, not sums of unrelated percentile
histograms. Twelve of the34 outliers wait over500ms for a worker. The daily
example instead spends758.18ms in its fill aggregate and559.85ms in original-fee
aggregation; both remain below the2s per-statement deadline. Fifteen outliers
have over100ms scheduled-client delay;16 have over100ms between dispatch and
handler entry. The categories overlap and must not be added as disjoint causes.

Connection-pool admission is distinct from the entire checkout: cumulative API
admission p99 is0.405ms, while one checkout contains a723.55ms `pre_ping` round
trip. There is no evidence that exhaustion of physical connection slots is the
dominant cause, so this investigation does not justify increasing the pool.
A separate retained history SQL span lasts675.43ms while its matching backend
is already `idle in transaction / ClientRead` at a sample during that interval,
with no blocking PID. Client-side SQL timing therefore includes receipt and
scheduling, not only server execution. That sample does not exclude other DB
waits between observations or identify why the client was delayed.

Eight API watchdog stall samples reach628.63ms. Seventeen of the34 outliers
overlap an API stall and25 overlap an API GC event; largest API GC is91.49ms.
The two selected stalled stacks show a constant-time daily-cache lookup and a
fill response validation interrupted by the test GC callback. A sampled frame
does not prove that function consumed the entire interval. No cache-lookup bug,
exclusive GC trigger or unique cause of the old failure is established. Engine
stalls/GC are deliberately excluded from API overlap attribution because they
run in a different process.

### Trace quality and practical next step

Client/API/engine sinks report zero dropped records; API reports zero dropped
child spans. The engine reports100 bounded child-span omissions, while selected
slow roots report zero. The diagnostic PG sampler records two200ms query
cancellations, distinct from application reporting timeouts. Missing samples
around a burst prevent complete DB-wait attribution. Whole-window cgroup
observation is bounded across298.837s with41 throttled periods and2.870s reported
throttling; those counters cannot be added to a request's duration or assigned
exclusively to one function. Tracing and changing host conditions prevent a
causal speedup claim from comparison with the untraced run.

The bounded investigation is complete: worker queueing and several transient
round-trip/scheduling delays are observed, while an exclusive old source-level
trigger remains unproven. No additional runtime change, cache, worker/pool
increase or timeout relaxation is made. If API tail latency becomes an operator
priority, first compare the shipping entrypoint with this diagnostic wrapper
under matched two-CPU conditions. If ordinary reads still queue behind heavy
reports, use Red/Green tests for one bounded heavy-report admission lane while
retaining the total worker/connection limits, control priority, cancellation
ownership and starvation protection. That change is a proposal, not shipped work.

After the probe, the first immediate status read fails with
`ServerDisconnectedError` before restored API readiness has been established;
the failed helper log is retained. A later independent status/ledger read and
packaged REST/public/privateWS preflight pass. Four ledger hashes and all23
existing fills remain intact, nine source/container runtime hashes match, private
configuration is unchanged, and canonical Demo is trading-stopped with no HALT,
pending mutation or unresolved order. No Demo order or account mutation is sent.
